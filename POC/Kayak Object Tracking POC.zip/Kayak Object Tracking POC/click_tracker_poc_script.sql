create database kayak;

create table click_tracker (userId varchar(255),sessionId varchar(255),eventTime datetime, eventName varchar(255),pageId varchar(255),buttonId varchar(255),objectId varchar(255));